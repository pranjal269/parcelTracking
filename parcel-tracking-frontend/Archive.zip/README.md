# Paracel Tracking Frontend

## Setup
1. Clone this repo.
2. `npm install`
3. `npm start`
4. Make sure the ASP .NET Core backend is running at http://localhost:8080.

Note: Environment variables are not needed because the backend URL is hard-coded in the API client. 